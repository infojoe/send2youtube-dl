from module.utils import html_unescape
#deprecated
unescape = html_unescape